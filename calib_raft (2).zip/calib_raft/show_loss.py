import numpy as np
import matplotlib.pyplot as plt
if __name__ == '__main__':
    loadData1 = np.load('r6epoch_40.npy')
    loadData2 = np.load('t6epoch_80_2.npy')
    loadData3 = np.load('t6epoch_80.npy')
    #loadData4 = np.load('t6epoch_80.npy')
    loadData2 = loadData2[0:90000]#.reshape(-1,100)
    #loadData2 = np.mean(loadData2,axis=1)
    x = range(0, len(loadData2))
    plt.plot(x, loadData2, '.-')
    plt_title = 'BATCH_SIZE = 32; LEARNING_RATE:0.001'
    plt.title(plt_title)
    plt.xlabel('x')
    plt.ylabel('LOSS')
    # plt.savefig(file_name)
    plt.show()
    print(1)