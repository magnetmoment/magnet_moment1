import os.path
import time
import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_scatter
import torchvision.models as models
from torch.autograd import Variable

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'
from utils import quat2mat_batch, tvector2mat_batch



# __all__ = [
#     'calib_net'
# ]
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(BasicBlock, self).__init__()
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = nn.BatchNorm2d(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        self.conv1 = conv1x1(inplanes, planes)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = conv3x3(planes, planes, stride)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = conv1x1(planes, planes * self.expansion)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion)
        self.elu = nn.ELU()
        self.leakyRELU = nn.LeakyReLU(0.1)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.leakyRELU(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.leakyRELU(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.leakyRELU(out)

        return out


def conv3x3(in_planes, out_planes, stride=1, groups=1, dilation=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=dilation, groups=groups, bias=False, dilation=dilation)


def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


def myconv(in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1):
    return nn.Sequential(
        nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation,
                  groups=1, bias=True),
        nn.LeakyReLU(0.1))


def predict_flow(in_planes):
    return nn.Conv2d(in_planes, 2, kernel_size=3, stride=1, padding=1, bias=True)


def deconv(in_planes, out_planes, kernel_size=4, stride=2, padding=1):
    return nn.ConvTranspose2d(in_planes, out_planes, kernel_size, stride, padding, bias=True)


class ResnetEncoder(nn.Module):
    """Pytorch module for a resnet encoder
    """

    def __init__(self, num_layers, pretrained, num_input_images=1):
        super(ResnetEncoder, self).__init__()

        self.num_ch_enc = np.array([64, 64, 128, 256, 512])

        resnets = {18: models.resnet18,
                   34: models.resnet34,
                   50: models.resnet50,
                   101: models.resnet101,
                   152: models.resnet152}

        if num_layers not in resnets:
            raise ValueError("{} is not a valid number of resnet layers".format(num_layers))

        self.encoder = resnets[num_layers](pretrained)

        if num_layers > 34:
            self.num_ch_enc[1:] *= 4

    def forward(self, input_image):
        self.features = []
        x = (input_image - 0.45) / 0.225  # 归一化 B，3，256，512  192 640 -> 160
        x = self.encoder.conv1(x)  # B，64，128，256
        x = self.encoder.bn1(x)  # B，64，128，256
        self.features.append(self.encoder.relu(x))  # 1，64，128，256
        # self.features.append(self.encoder.layer1(self.encoder.maxpool(self.features[-1])))
        self.features.append(self.encoder.maxpool(self.features[-1]))  # POOL
        self.features.append(self.encoder.layer1(self.features[-1]))  # 32，64，64，128
        self.features.append(self.encoder.layer2(self.features[-1]))  # 32，128，32，64
        self.features.append(self.encoder.layer3(self.features[-1]))  # 32，256，16，32
        self.features.append(self.encoder.layer4(self.features[-1]))  # 32，512，8，16

        return self.features  #


def get_pointmap(im, x, y, align=False):
    """
    Args:
        im: (H, W, C) [y, x]
        x: (N)
        y: (N)

    Returns:

    """
    H, W = im.shape[-2:]#B N 2
    x = 2 * x / (W - 1) - 1
    y = 2 * y / (H - 1) - 1

    grid = torch.cat([x, y], dim=-1)
    img = F.grid_sample(im, grid, align_corners=True)
    return img

def bilinear_interpolate_torch(im, x, y, align=False):
    """
    Args:
        im: (H, W, C) [y, x]
        x: (N)
        y: (N)

    Returns:

    """
    batch = x.shape[0]
    N = x.shape[1]

    x0 = torch.floor(x).long()
    x1 = x0 + 1

    y0 = torch.floor(y).long()
    y1 = y0 + 1

    x0 = torch.clamp(x0, 0, im.shape[3] - 1)
    x1 = torch.clamp(x1, 0, im.shape[3] - 1)
    y0 = torch.clamp(y0, 0, im.shape[2] - 1)
    y1 = torch.clamp(y1, 0, im.shape[2] - 1)

    x0_f = x0.reshape(-1)
    x1_f = x1.reshape(-1)
    y0_f = y0.reshape(-1)
    y1_f = y1.reshape(-1)

    B = torch.arange(0, batch).unsqueeze(-1).expand(-1, N).reshape(-1)
    Ia = im[B, :, y0_f, x0_f]
    Ib = im[B, :, y1_f, x0_f]
    Ic = im[B, :, y0_f, x1_f]
    Id = im[B, :, y1_f, x1_f]
    # y_show = y0_f.cpu().numpy()
    # x_show = x0_f.cpu().numpy()

    Ia = Ia.reshape(batch, N, -1)
    Ib = Ib.reshape(batch, N, -1)
    Ic = Ic.reshape(batch, N, -1)
    Id = Id.reshape(batch, N, -1)

    if align:
        x0 = x0.float() + 0.5
        x1 = x1.float() + 0.5
        y0 = y0.float() + 0.5
        y1 = y1.float() + 0.5

    wa = (x1.type_as(x) - x) * (y1.type_as(y) - y)
    wb = (x1.type_as(x) - x) * (y - y0.type_as(y))
    wc = (x - x0.type_as(x)) * (y1.type_as(y) - y)
    wd = (x - x0.type_as(x)) * (y - y0.type_as(y))
    ans = Ia * wa.unsqueeze(-1) + Ib * wb.unsqueeze(-1) + \
          Ic * wc.unsqueeze(-1) + Id * wd.unsqueeze(-1)
    return ans


class SparseinvariantConv(nn.Module):

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size):
        super().__init__()

        padding = kernel_size // 2

        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            padding=padding,
            bias=False)

        self.bias = nn.Parameter(
            torch.zeros(out_channels),
            requires_grad=True)

        self.sparsity = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            padding=padding,
            bias=False)

        kernel = torch.FloatTensor(torch.ones([kernel_size, kernel_size])).unsqueeze(0).unsqueeze(0)

        self.sparsity.weight = nn.Parameter(
            data=kernel,
            requires_grad=False)

        self.relu = nn.ReLU(inplace=True)

        self.max_pool = nn.MaxPool2d(
            kernel_size,
            stride=1,
            padding=padding)

    def forward(self, x, mask, relu=True):
        x = x * mask
        x = self.conv(x)
        normalizer = 1 / torch.clamp(self.sparsity(mask), 1)
        x = x * normalizer + self.bias.unsqueeze(0).unsqueeze(2).unsqueeze(3)
        if relu:
            x = self.relu(x)

        mask = self.max_pool(mask)

        return x, mask


class Sparseinvariantavg(nn.Module):

    def __init__(self,
                 in_channels=2,
                 kernel_size=2,
                 stride=2):
        super().__init__()

        self.sparsity = nn.Conv2d(
            in_channels,
            in_channels,
            kernel_size=(kernel_size, kernel_size),
            stride=(stride, stride),
            bias=False)

        kernel = torch.FloatTensor(torch.ones([kernel_size, kernel_size])) \
            .unsqueeze(0).unsqueeze(0).expand(in_channels, in_channels, -1, -1)

        self.sparsity.weight = nn.Parameter(
            data=kernel,
            requires_grad=False)

        self.sparsity2 = nn.Conv2d(
            1,
            1,
            kernel_size=(kernel_size, kernel_size),
            stride=(stride, stride),
            bias=False)

        kernel = torch.FloatTensor(torch.ones([kernel_size, kernel_size])).unsqueeze(0).unsqueeze(0)

        self.sparsity2.weight = nn.Parameter(
            data=kernel,
            requires_grad=False)

        self.max_pool = nn.MaxPool2d(
            kernel_size=kernel_size,
            stride=stride)

    def forward(self, x, mask):
        x1 = x * mask
        x = self.sparsity(x1)
        x = x / torch.clamp(self.sparsity2(mask), 1)

        mask = self.max_pool(mask)

        return x, mask


class LCCNet(nn.Module):
    """
    Based on the PWC-DC net. add resnet encoder, dilation convolution and densenet connections
    """

    def __init__(self, md=4, use_reflectance=False, dropout=0.0,
                 Action_Func='leakyrelu', attention=False, res_num=18):
        """
        input: md --- maximum displacement (for correlation. default: 4), after warpping
        """
        super(LCCNet, self).__init__()
        input_lidar = 1
        self.res_num = res_num
        self.use_feat_from = 6
        use_feat_from = 6
        if use_reflectance:
            input_lidar = 2

        # original resnet
        self.pretrained_encoder = True
        self.net_encoder = ResnetEncoder(num_layers=self.res_num, pretrained=True, num_input_images=1)

        # resnet with leakyRELU
        self.Action_Func = Action_Func
        self.attention = attention
        if self.res_num == 50:
            layers = [3, 4, 6, 3]
            add_list = [1024, 512, 256, 64]
        elif self.res_num == 18:
            layers = [2, 2, 2, 2]
            add_list = [256, 128, 64, 64]

        if self.res_num == 50:
            block = Bottleneck
        elif self.res_num == 18:
            block = BasicBlock

        # rgb_image
        self.inplanes = 64
        # self.conv1_rgb = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3)
        # self.elu_rgb = nn.ELU()
        # self.leakyRELU_rgb = nn.LeakyReLU(0.1)
        # self.maxpool_rgb = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        # self.layer1_rgb = self._make_layer(block, 64, layers[0])
        # self.layer2_rgb = self._make_layer(block, 128, layers[1], stride=2)
        # self.layer3_rgb = self._make_layer(block, 256, layers[2], stride=2)
        # self.layer4_rgb = self._make_layer(block, 512, layers[3], stride=2)

        # lidar_image
        self.inplanes = 64
        self.conv0_lidar = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, stride=2, padding=1),
            nn.LeakyReLU(0.1)
        )

        # 174 640 -> 128,512
        self.conv1_lidar = nn.Sequential(
            nn.Conv2d(16, 64, kernel_size=3, stride=2, padding=1),
            nn.LeakyReLU(0.1),
        )
        self.maxpool_lidar = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1_lidar = self._make_layer(block, 64, layers[0])
        self.layer2_lidar = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3_lidar = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4_lidar = self._make_layer(block, 512, layers[3], stride=2)

        self.corr = Correlation(pad_size=md, kernel_size=1, max_displacement=md, stride1=1, stride2=1,
                                corr_multiply=1)  # md=4
        self.leakyRELU = nn.LeakyReLU(0.1)

        nd = (2 * md + 1) ** 2
        od = nd

        # 稠密化光流
        # 111111111111111
        self.conv6_0 = myconv(od, 128, kernel_size=3, stride=1)
        self.conv6_1 = myconv(128, 128, kernel_size=3, stride=1)
        self.conv6_2 = myconv(128, 96, kernel_size=3, stride=1)
        self.conv6_3 = myconv(96, 64, kernel_size=3, stride=1)
        self.conv6_4 = myconv(64, 32, kernel_size=3, stride=1)

        self.fc6 = nn.Linear(3840, 512)

        self.fc1_trasl6 = nn.Linear(512, 256)
        self.fc1_rot6 = nn.Linear(512, 256)

        self.fc2_trasl6 = nn.Linear(256, 3)
        self.fc2_rot6 = nn.Linear(256, 4)

        # 2222222222222
        od5 = nd + add_list[0]
        # self.conv5_c = myconv(od5, 128, kernel_size=1, stride=1, padding=0)
        self.conv5_0 = myconv(od5, 128, kernel_size=3, stride=1)
        self.conv5_1 = myconv(128, 128, kernel_size=3, stride=2)
        self.conv5_2 = myconv(128, 96, kernel_size=3, stride=1)
        self.conv5_3 = myconv(96, 64, kernel_size=3, stride=1)
        self.conv5_4 = myconv(64, 32, kernel_size=3, stride=1)

        self.fc5 = nn.Linear(3840, 512)

        self.fc1_trasl5 = nn.Linear(512, 256)
        self.fc1_rot5 = nn.Linear(512, 256)

        self.fc2_trasl5 = nn.Linear(256, 3)
        self.fc2_rot5 = nn.Linear(256, 4)
        # 3333333333333
        od4 = nd + add_list[1]
        # self.conv4_c = myconv(od4, 128, kernel_size=1, stride=1, padding=0)
        self.conv4_0 = myconv(od4, 128, kernel_size=3, stride=1)
        self.conv4_1 = myconv(128, 128, kernel_size=3, stride=2)
        self.conv4_2 = myconv(128, 96, kernel_size=3, stride=2)
        self.conv4_3 = myconv(96, 64, kernel_size=3, stride=1)
        self.conv4_4 = myconv(64, 32, kernel_size=3, stride=1)

        self.fc4 = nn.Linear(3840, 512)

        self.fc1_trasl4 = nn.Linear(512, 256)
        self.fc1_rot4 = nn.Linear(512, 256)

        self.fc2_trasl4 = nn.Linear(256, 3)
        self.fc2_rot4 = nn.Linear(256, 4)
        # 4444444444
        od3 = nd + add_list[2]
        # self.conv3_c = myconv(od3, 128, kernel_size=1, stride=1, padding=0)
        self.conv3_0 = myconv(od3, 128, kernel_size=3, stride=1)
        self.conv3_1 = myconv(128, 128, kernel_size=3, stride=2)
        self.conv3_2 = myconv(128, 96, kernel_size=3, stride=2)
        self.conv3_3 = myconv(96, 64, kernel_size=3, stride=2)
        self.conv3_4 = myconv(64, 32, kernel_size=3, stride=1)

        self.fc3 = nn.Linear(3840, 512)

        self.fc1_trasl3 = nn.Linear(512, 256)
        self.fc1_rot3 = nn.Linear(512, 256)

        self.fc2_trasl3 = nn.Linear(256, 3)
        self.fc2_rot3 = nn.Linear(256, 4)

        self.project6 = nn.Linear(4, 256)
        self.project61 = nn.Linear(256, 256)
        self.project5 = nn.Linear(4, 128)
        self.project51 = nn.Linear(128, 128)
        self.project4 = nn.Linear(4, 64)
        self.project41 = nn.Linear(64, 64)

    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                conv1x1(self.inplanes, planes * block.expansion, stride),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(self.inplanes, planes))

        return nn.Sequential(*layers)

    def warp(self, x, flo, mask_flow):
        """
        warp an image/tensor (im2) back to im1, according to the optical flow
        x: [B, C, H, W] (im2)
        flo: [B, 2, H, W] flow
        """
        B, C, H, W = x.size()
        # mesh grid
        xx = torch.arange(0, W).view(1, -1).repeat(H, 1)
        yy = torch.arange(0, H).view(-1, 1).repeat(1, W)
        xx = xx.view(1, 1, H, W).repeat(B, 1, 1, 1)
        yy = yy.view(1, 1, H, W).repeat(B, 1, 1, 1)
        grid = torch.cat((xx, yy), 1).float()

        if x.is_cuda:
            grid = grid.cuda()
        vgrid = Variable(grid) + flo  # 光流从gt到现在

        # scale grid to [-1,1]
        vgrid[:, 0, :, :] = 2.0 * vgrid[:, 0, :, :].clone() / max(W - 1, 1) - 1.0
        vgrid[:, 1, :, :] = 2.0 * vgrid[:, 1, :, :].clone() / max(H - 1, 1) - 1.0

        vgrid = vgrid.permute(0, 2, 3, 1)
        output = nn.functional.grid_sample(x, vgrid)
        mask = torch.autograd.Variable(torch.ones(x.size())).cuda()
        mask = nn.functional.grid_sample(mask, vgrid)

        # if W==128:
        # np.save('mask.npy', mask.cpu().data.numpy())
        # np.save('warp.npy', output.cpu().data.numpy())

        # mask[mask<0.9999] = 0.0
        # mask[mask>0] = 1.0
        mask = torch.floor(torch.clamp(mask, 0, 1))

        return output * mask * mask_flow

    def warp2(self, x, uv, uv_new, mask, mask_new):
        B, C, H, W = x.size()
        scale = H / 384
        uv_down = uv * scale
        uv_new_down = uv_new * scale

        delta_uv = uv_new_down - (torch.floor(uv_new_down) + 0.5)
        norm_uv = torch.cat([uv_new_down[:, :, 0:1] / W, uv_new_down[:, :, 1:2] / H],dim=-1)
        uv_info = torch.cat([delta_uv,norm_uv],dim=-1)

        mask_new2 = (uv_new[:, :, 0] < 1280) & (uv_new[:, :, 0] >= 0) & \
                    (uv_new[:, :, 1] < 384) & (uv_new[:, :, 1] >= 0)  # BN
        mask_new = (mask_new2 * mask_new * mask).view(-1)
        uv_new_index = uv_new_down.long()
        B_channel = torch.arange(0, uv_new_down.shape[0]).cuda().unsqueeze(-1).unsqueeze(-1).expand(-1, uv_new.shape[1],
                                                                                                    -1).long()
        uv_new_index = torch.cat([B_channel, uv_new_index], dim=-1).view(-1, 3)  # 索引位置 BN 3
        # x[:, :, :, :] = 0
        # for b in range(B):
        #     for h in range(H):
        #         for w in range(W):
        #             x[b, 0, h, w] = b
        #             x[b, 1, h, w] = h
        #             x[b, 2, h, w] = w
        feature = bilinear_interpolate_torch(x, uv_down[:, :, 0], uv_down[:, :, 1]).view(-1, C)  # BN C
        feature = feature[mask_new, :]
        uv_info = uv_info.view(-1,uv_info.shape[-1])[mask_new, :]

        if (C == 256):
            uv_feature = self.leakyRELU(feature + self.project6(uv_info))
            feature = self.project61(feature)
        if (C == 128):
            uv_feature = self.leakyRELU(feature + self.project5(uv_info))
            feature = self.project51(feature)
        if (C == 64):
            uv_feature = self.leakyRELU(feature + self.project4(uv_info))
            feature = self.project41(feature)
        valid_uv_new_index = uv_new_index[mask_new, :]  # 新位置的index
        valid_index = valid_uv_new_index[:, 0] * H * W + valid_uv_new_index[:, 2] * W + valid_uv_new_index[:, 1]
        valid_unq_coords, valid_unq_coords_inv, _ = torch.unique(valid_index, return_inverse=True, return_counts=True,
                                                                 dim=0)
        # 在同一个新位置的特征用平均处理
        B_valid = valid_unq_coords // (H * W)
        H_valid = (valid_unq_coords % (H * W)) // W
        W_valid = valid_unq_coords % W
        # valid_max_feature = torch_scatter.scatter_max(feature, valid_unq_coords_inv, dim=0)[0]
        valid_avg_feature = torch_scatter.scatter_mean(feature, valid_unq_coords_inv, dim=0)
        warp = torch.zeros([B, C, H, W], dtype=torch.float32).cuda()
        warp[B_valid, :, H_valid, W_valid] = valid_avg_feature
        mask_new = mask_new.view(B, -1).unsqueeze(1).unsqueeze(-1)
        return warp, mask_new

    def backbone(self, rgb, lidar):

        features1 = self.net_encoder(rgb)  # snet encode  6 feature 64，64，64，128，256，512
        c12 = features1[0]  # 2 1，64，128，256
        c13 = features1[2]  # 4 1，64，64，128
        c14 = features1[3]  # 8 1,128，32，64
        c15 = features1[4]  # 16 1，256，16，32
        c16 = features1[5]  # 32 1，512，8，16

        x2 = self.conv0_lidar(lidar)  # 1，64，128，256
        c22 = self.conv1_lidar(x2)  # 1，64，128，256

        c23 = self.layer1_lidar(self.maxpool_lidar(c22))  # 4 pool 32,64,64,128
        c24 = self.layer2_lidar(c23)  # 8  32，128，32，64
        c25 = self.layer3_lidar(c24)  # 16  32，256，16，32
        c26 = self.layer4_lidar(c25)
        # print(c26[0])
        return c12, c13, c14, c15, c16, c22, c23, c24, c25, c26

    def forward(self, sample):  # B，N，H  插值
        # rgb_image
        # 1.主干网络
        # 2.初始化参数 mask
        # 3.warp,推理q和t，7.13改成稠密链接
        # 4.计算这个层次的光流
        # 5.判断点的个数,点少于5个则判断此次迭代失败
        rgb, lidar, uv, pcl_xyz, mask, K = sample['rgb'].cuda(), sample['lidar_input'].cuda(), \
            sample['uv'].cuda(), sample['pcl_xyz'].cuda(), sample['mask'].cuda(), sample['calib'].cuda()
        # rgb, lidar, uv, pcl_xyz, mask, K = sample['rgb'], sample['lidar_input'], \
        #     sample['uv'], sample['pcl_xyz'], sample['mask'], sample['calib']
        K = K.float()
        uv = uv.float()
        pcl_xyz6 = pcl_xyz.clone()
        c12, c13, c14, c15, c16, c22, c23, c24, c25, c26 = self.backbone(rgb, lidar)

        # 准备参数
        valid_list = torch.zeros(uv.shape[0], 5, dtype=torch.bool).cuda()  # 如果一次迭代以后,小于10个点在相机视野内,后面的迭代loss置零
        # K2, K3, K4, K5 = self.get_K(K)

        # 第一次迭代 384 1280  192 640  ||  96 320  48 160  24 80  12 40  6 20
        corr6 = self.corr(c16, c26)
        corr6 = self.leakyRELU(corr6)
        x = self.conv6_0(corr6)
        x = self.conv6_1(x)
        x = self.conv6_2(x)
        x = self.conv6_3(x)
        x = self.conv6_4(x)
        # num = mask.float().sum(dim=1)
        x = x.view(x.shape[0], -1)
        x = self.leakyRELU(self.fc6(x))
        t6 = self.leakyRELU(self.fc1_trasl6(x))
        q6 = self.leakyRELU(self.fc1_rot6(x))
        t6 = self.fc2_trasl6(t6)
        q6 = self.fc2_rot6(q6)
        q6 = F.normalize(q6, dim=1)
        # print(q6)

        R_target6 = quat2mat_batch(q6)  # 0.9974
        T_target6 = tvector2mat_batch(t6)  # -0.3869
        RT_target6 = torch.bmm(T_target6, R_target6)

        pcl_xyz5 = torch.bmm(RT_target6, pcl_xyz6.detach())  # 现在到gt
        mask_new = pcl_xyz5[:, 3, :] > 1e-6
        # 新的uv
        uv5 = torch.bmm(K, pcl_xyz5[:, 0:3, :])
        temp = uv5[:, 2, :].clone()
        temp = torch.clamp(temp, 1e-6)
        uv5[:, 0, :] = uv5[:, 0, :].clone() / temp
        uv5[:, 1, :] = uv5[:, 1, :].clone() / temp
        uv5 = uv5[:, 0:2, :].permute(0, 2, 1)
        uv5 = uv5.detach()

        # 第二次迭代
        warp5, mask5 = self.warp2(c25, uv, uv5, mask, mask_new)

        valid_iter = (mask5.int().squeeze(1).squeeze(-1).sum(dim=1) > 5)
        valid_list[:, 0] = True
        valid_list[:, 1] = valid_iter

        corr5 = self.corr(c15, warp5)
        corr5 = self.leakyRELU(corr5)

        x = torch.cat((corr5, c15), 1)
        x = self.conv5_0(x)
        x = self.conv5_1(x)
        x = self.conv5_2(x)
        x = self.conv5_3(x)
        x = self.conv5_4(x)

        x = x.view(x.shape[0], -1)
        x = self.leakyRELU(self.fc5(x))
        t5 = self.leakyRELU(self.fc1_trasl5(x))
        q5 = self.leakyRELU(self.fc1_rot5(x))
        t5 = self.fc2_trasl5(t5)
        q5 = self.fc2_rot5(q5)
        q5 = F.normalize(q5, dim=1)

        R_target5 = quat2mat_batch(q5)
        T_target5 = tvector2mat_batch(t5)
        RT_target5 = torch.bmm(T_target5, R_target5)
        pcl_xyz4 = torch.bmm(RT_target5, pcl_xyz5.detach())  # 现在到gt
        mask_new = pcl_xyz4[:, 3, :] > 1e-6
        uv4 = torch.bmm(K, pcl_xyz4[:, 0:3, :])  # 新的uv
        temp = torch.clamp(uv4[:, 2, :].clone(), 1e-6)
        uv4[:, 0, :] = uv4[:, 0, :].clone() / temp
        uv4[:, 1, :] = uv4[:, 1, :].clone() / temp
        uv4 = uv4[:, 0:2, :].permute(0, 2, 1)
        uv4 = uv4.detach()
        # 第三次迭代
        warp4, mask4 = self.warp2(c24, uv, uv4, mask, mask_new)

        valid_iter = (mask4.int().squeeze(1).squeeze(-1).sum(dim=1) > 5)
        valid_list[:, 2] = valid_iter * valid_list[:, 1]  # 前一次迭代失败,后面都视为失败

        corr4 = self.corr(c14, warp4)
        corr4 = self.leakyRELU(corr4)

        x = torch.cat((corr4, c14), 1)
        x = self.conv4_0(x)
        x = self.conv4_1(x)
        x = self.conv4_2(x)
        x = self.conv4_3(x)
        x = self.conv4_4(x)

        x = x.view(x.shape[0], -1)
        x = self.leakyRELU(self.fc4(x))
        t4 = self.leakyRELU(self.fc1_trasl4(x))
        q4 = self.leakyRELU(self.fc1_rot4(x))
        t4 = self.fc2_trasl4(t4)
        q4 = self.fc2_rot4(q4)
        q4 = F.normalize(q4, dim=1)

        R_target4 = quat2mat_batch(q4)
        T_target4 = tvector2mat_batch(t4)
        RT_target4 = torch.bmm(T_target4, R_target4)
        pcl_xyz3 = torch.bmm(RT_target4, pcl_xyz4.detach())  # 现在到gt
        mask_new = pcl_xyz3[:, 3, :] > 1e-6

        uv3 = torch.bmm(K, pcl_xyz3[:, 0:3, :])  # 新的uv
        temp = torch.clamp(uv3[:, 2, :].clone(), 1e-3)
        uv3[:, 0, :] = uv3[:, 0, :].clone() / temp
        uv3[:, 1, :] = uv3[:, 1, :].clone() / temp
        uv3 = uv3[:, 0:2, :].permute(0, 2, 1)
        uv3 = uv3.detach()

        # 第四次迭代
        warp3, mask3 = self.warp2(c23, uv, uv3, mask, mask_new)
        valid_iter = (mask3.int().squeeze(1).squeeze(-1).sum(dim=1) > 5)
        valid_list[:, 3] = valid_iter * valid_list[:, 2]

        corr3 = self.corr(c13, warp3)
        corr3 = self.leakyRELU(corr3)

        x = torch.cat((corr3, c13), 1)
        x = self.conv3_0(x)
        x = self.conv3_1(x)
        x = self.conv3_2(x)
        x = self.conv3_3(x)
        x = self.conv3_4(x)

        x = x.view(x.shape[0], -1)
        x = self.leakyRELU(self.fc3(x))
        t3 = self.leakyRELU(self.fc1_trasl3(x))
        q3 = self.leakyRELU(self.fc1_rot3(x))
        t3 = self.fc2_trasl3(t3)
        q3 = self.fc2_rot3(q3)
        q3 = F.normalize(q3, dim=1)

        # q5, t5, q4, t4, q3, t3, q2, t2, valid_list
        return q6, t6, q5, t5, q4, t4, q3, t3, q3, t3, valid_list  # transl, rot
