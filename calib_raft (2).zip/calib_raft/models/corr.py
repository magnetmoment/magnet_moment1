import torch
import torch.nn.functional as F
from .utils import bilinear_sampler, coords_grid

try:
    import alt_cuda_corr
except:
    # alt_cuda_corr is not compiled
    pass


class CorrBlock:
    def __init__(self, fmap1, fmap2, num_levels=4, radius=4):
        self.num_levels = num_levels
        self.radius = radius
        self.corr_pyramid = []
        self.H = fmap2.shape[-2]
        self.W = fmap2.shape[-1]
        # all pairs correlation
        corr = CorrBlock.corr(fmap1, fmap2)

        batch, h1, w1, dim, h2, w2 = corr.shape
        corr = corr.reshape(batch * h1 * w1, dim, h2, w2)

        self.corr_pyramid.append(corr.view(batch, h1, w1, h2, w2))
        for i in range(self.num_levels - 1):
            corr = F.avg_pool2d(corr, 2, stride=2)
            self.corr_pyramid.append(corr.view(batch, h1, w1, h2 // 2 ** (i+1), w2 // 2 ** (i+1)))

    def __call__(self, uv0, uv1):  # 4D张量的插值
        batch, N, _ = uv0.shape
        r = self.radius
        x = uv0[:, :, 0:1].repeat(1, 1, (2 * r + 1)*(2 * r + 1)).unsqueeze(-1)
        y = uv0[:, :, 1:2].repeat(1, 1, (2 * r + 1)*(2 * r + 1)).unsqueeze(-1)

        x0 = torch.floor(uv0[:, :, 0:1]).long().repeat(1, 1, (2 * r + 1)*(2 * r + 1)).unsqueeze(-1)  # B 20000 49 1
        x1 = x0 + 1
        y0 = torch.floor(uv0[:, :, 1:2]).long().repeat(1, 1, (2 * r + 1)*(2 * r + 1)).unsqueeze(-1)  # B 20000 49 1
        y1 = y0 + 1

        dx = torch.linspace(-r, r, 2 * r + 1, device=uv0.device)
        dy = torch.linspace(-r, r, 2 * r + 1, device=uv0.device)
        delta = torch.stack(torch.meshgrid(dy, dx), axis=-1)
        B_all = torch.arange(0, batch).reshape(-1, 1, 1, 1, 1).expand(batch, N, (2 * r + 1) * (2 * r + 1), 16, 1).cuda()
        delta_lvl = delta.view(1, 2 * r + 1, 2 * r + 1, 2)
        volumn_selects = []
        for i in range(self.num_levels):
            centroid_lvl = uv1.reshape(-1, 1, 1, 2) / 2 ** i
            volumn_4D = self.corr_pyramid[i]
            coords_lvl = centroid_lvl + delta_lvl
            coords_lvl = coords_lvl.view(batch, N, (2 * r + 1) * (2 * r + 1), 2)  # B 20000 49 2
            z = coords_lvl[:, :,:, 0:1]
            u = coords_lvl[:, :,:, 1:2]
            z0 = torch.floor(coords_lvl[:, :, :, 0]).long().unsqueeze(-1)  # B 20000 49 1
            z1 = z0 + 1
            u0 = torch.floor(coords_lvl[:, :, :, 1]).long().unsqueeze(-1)  # B 20000 49 1
            u1 = u0 + 1

            indices = torch.cat([torch.stack([x0, y0, z0, u0], dim=-1),
                                 torch.stack([x0, y0, z0, u1], dim=-1),
                                 torch.stack([x0, y0, z1, u0], dim=-1),
                                 torch.stack([x0, y0, z1, u1], dim=-1),

                                 torch.stack([x0, y1, z0, u0], dim=-1),
                                 torch.stack([x0, y1, z0, u1], dim=-1),
                                 torch.stack([x0, y1, z1, u0], dim=-1),
                                 torch.stack([x0, y1, z1, u1], dim=-1),

                                 torch.stack([x1, y0, z0, u0], dim=-1),
                                 torch.stack([x1, y0, z0, u1], dim=-1),
                                 torch.stack([x1, y0, z1, u0], dim=-1),
                                 torch.stack([x1, y0, z1, u1], dim=-1),

                                 torch.stack([x1, y1, z0, u0], dim=-1),
                                 torch.stack([x1, y1, z0, u1], dim=-1),
                                 torch.stack([x1, y1, z1, u0], dim=-1),
                                 torch.stack([x1, y1, z1, u1], dim=-1)], dim=-2)  # B 20000 49 16 4

            mask = ~((indices[:, :, :, :, 0] >= 0) & (indices[:, :, :, :, 1] < self.W / 2 ** i) & (
                    indices[:, :, :, :, 2] >= 0) & (indices[:, :, :, :, 3] < self.H / 2 ** i))  # B 20000 49 16
            indices[:, :, :, :, 2] = torch.clamp(indices[:, :, :, :, 2], 0, self.W / 2 ** i - 1)
            indices[:, :, :, :, 3] = torch.clamp(indices[:, :, :, :, 3], 0, self.H / 2 ** i - 1)
            indices = torch.cat([B_all, indices], dim=-1)
            volumn = volumn_4D[indices[:, :, :, :, 0], indices[:, :, :, :, 1],
            indices[:, :, :, :, 2], indices[:, :, :, :, 3], indices[:, :, :, :, 4]]  # B 20000 49 16
            volumn = volumn * mask

            x_0 = x1 - x
            x_1 = x - x0
            y_0 = y1 - y
            y_1 = y - y0
            z_0 = z1 - z
            z_1 = z - z0
            u_0 = u1 - u
            u_1 = u - u0

            volumn_select = \
                volumn[:, :, :, 0] * x_0 * y_0 * z_0 * u_0 + volumn[:, :, :, 1] * x_0 * y_0 * z_0 * u_1+\
                volumn[:, :, :, 2] * x_0 * y_0 * z_1 * u_0 + volumn[:, :, :, 3] * x_0 * y_0 * z_1 * u_1+\
                volumn[:, :, :, 4] * x_0 * y_1 * z_0 * u_0 + volumn[:, :, :, 5] * x_0 * y_1 * z_0 * u_1+\
                volumn[:, :, :, 6] * x_0 * y_1 * z_1 * u_0 + volumn[:, :, :, 7] * x_0 * y_1 * z_1 * u_1+\
                volumn[:, :, :, 8] * x_1 * y_0 * z_0 * u_0 + volumn[:, :, :, 9] * x_1 * y_0 * z_0 * u_1+\
                volumn[:, :, :, 10] * x_1 * y_0 * z_1 * u_0 + volumn[:, :, :, 11] * x_1 * y_0 * z_1 * u_1+\
                volumn[:, :, :, 12] * x_1 * y_1 * z_0 * u_0 + volumn[:, :, :, 13] * x_1 * y_1 * z_0 * u_1+\
                volumn[:, :, :, 14] * x_1 * y_1 * z_1 * u_0 + volumn[:, :, :, 15] * x_1 * y_1 * z_1 * u_1# B 20000 49

            volumn_selects.append(volumn_select)



        for i in range(self.num_levels):
            centroid_lvl = uv0.reshape(-1, 1, 1, 2) / 2 ** i
            delta_lvl = delta.view(1, 2 * r + 1, 2 * r + 1, 2)
            coords_lvl = centroid_lvl + delta_lvl

        # r = self.radius
        # cdim = coords.ndim
        # if(coords.ndim == 3):
        #     batch, N, _ = coords.shape[0]
        # else:
        #     coords = coords.permute(0, 2, 3, 1)
        #     batch, h1, w1, _ = coords.shape
        #
        # out_pyramid = []
        # for i in range(self.num_levels):
        #     corr = self.corr_pyramid[i]
        #     dx = torch.linspace(-r, r, 2 * r + 1, device=coords.device)
        #     dy = torch.linspace(-r, r, 2 * r + 1, device=coords.device)
        #     delta = torch.stack(torch.meshgrid(dy, dx), axis=-1)
        #     centroid_lvl = coords.reshape(-1, 1, 1, 2) / 2 ** i
        #     delta_lvl = delta.view(1, 2 * r + 1, 2 * r + 1, 2)
        #     coords_lvl = centroid_lvl + delta_lvl
        #
        #     corr = bilinear_sampler(corr, coords_lvl)
        #     corr = corr.view(batch, h1, w1, -1)
        #     out_pyramid.append(corr)
        #
        # out = torch.cat(out_pyramid, dim=-1)
        # return out.permute(0, 3, 1, 2).contiguous().float()

    @staticmethod
    def corr(fmap1, fmap2):

        batch, dim, ht, wd = fmap1.shape
        fmap1 = fmap1.view(batch, dim, ht * wd)
        fmap2 = fmap2.view(batch, dim, ht * wd)

        corr = torch.matmul(fmap1.transpose(1, 2), fmap2)
        corr = corr.view(batch, ht, wd, 1, ht, wd)
        return corr / torch.sqrt(torch.tensor(dim).float())


class CorrBlockv2:
    def __init__(self, img_fmap, point_fmap, uv, num_levels=4, radius=4):
        self.num_levels = num_levels
        self.radius = radius
        self.corr_pyramid = []

        # all pairs correlation
        import time
        for i in range(self.num_levels):
            corr = self.point_corr(point_fmap[i], img_fmap[i], uv / 2 ** i)
            batch, N, dim, h2, w2 = corr.shape
            corr = corr.reshape(batch * N, dim, h2, w2)
            self.corr_pyramid.append(corr)
        self.corr_pyramid.append(self.corr(point_fmap[-1], img_fmap[-1]))


    def __call__(self, coords):
        r = self.radius
        cdim = coords.ndim
        batch, N, _ = coords.shape

        out_pyramid = []
        for i in range(self.num_levels):
            corr = self.corr_pyramid[i]
            dx = torch.linspace(-r, r, 2 * r + 1, device=coords.device)
            dy = torch.linspace(-r, r, 2 * r + 1, device=coords.device)
            delta = torch.stack(torch.meshgrid(dy, dx), axis=-1)
            centroid_lvl = coords.reshape(-1, 1, 1, 2) / 2 ** i
            delta_lvl = delta.view(1, 2 * r + 1, 2 * r + 1, 2)
            coords_lvl = centroid_lvl + delta_lvl
            corr = bilinear_sampler(corr, coords_lvl.float())
            corr = corr.view(batch, N, -1)
            out_pyramid.append(corr)

        out = torch.cat(out_pyramid, dim=-1)
        return out.contiguous()

    @staticmethod
    def point_corr(pointmap, imgmap, uv):
        # B N 1 2
        H, W = imgmap.shape[-2:]
        xgrid, ygrid = uv.split([1, 1], dim=-1)
        xgrid = 2 * xgrid / (W - 1) - 1
        ygrid = 2 * ygrid / (H - 1) - 1

        grid = torch.cat([xgrid, ygrid], dim=-1).unsqueeze(-2).float()
        point_feature = F.grid_sample(pointmap, grid, align_corners=False)# B C N 1

        batch, dim, ht, wd = imgmap.shape
        N = point_feature.shape[-2]
        point_feature = point_feature.view(batch, dim, -1)
        imgmap = imgmap.view(batch, dim, ht * wd)

        corr = torch.matmul(point_feature.transpose(1, 2), imgmap)
        corr = corr.view(batch, N, 1, ht, wd)
        return corr / torch.sqrt(torch.tensor(dim).float())

    @staticmethod
    def point_corrv2(pointmap, imgmap, uv):
        batch, dim, ht, wd = pointmap.shape
        pointmap = pointmap.view(batch, dim, ht * wd)
        imgmap = imgmap.view(batch, dim, ht * wd)
        N = uv.shape[1]
        corr = torch.matmul(pointmap.transpose(1, 2), imgmap)
        corr = corr.view(batch, ht, wd, 1, ht, wd)
        corr = corr.view(batch, ht, wd, -1).permute(0,3,1,2)
        xgrid, ygrid = uv.split([1, 1], dim=-1)
        xgrid = 2 * xgrid / (ht - 1) - 1
        ygrid = 2 * ygrid / (wd - 1) - 1
        grid = torch.cat([xgrid, ygrid], dim=-1).unsqueeze(-2).float()#batch, N, dim, h2, w2
        corr = F.grid_sample(corr, grid, align_corners=False).permute(0,2,3,1).view(batch, N, 1, ht, wd)# B C N 1 -> B N 1 C -> B N 1 h w
        return corr / torch.sqrt(torch.tensor(dim).float())

    @staticmethod
    def corr(fmap1, fmap2):

        batch, dim, ht, wd = fmap1.shape
        fmap1 = fmap1.view(batch, dim, ht * wd)
        fmap2 = fmap2.view(batch, dim, ht * wd)

        corr = torch.matmul(fmap1.transpose(1, 2), fmap2)
        corr = corr.view(batch, ht, wd, 1, ht, wd)
        return corr / torch.sqrt(torch.tensor(dim).float())


class AlternateCorrBlock:
    def __init__(self, fmap1, fmap2, num_levels=4, radius=4):
        self.num_levels = num_levels
        self.radius = radius

        self.pyramid = [(fmap1, fmap2)]
        for i in range(self.num_levels):
            fmap1 = F.avg_pool2d(fmap1, 2, stride=2)
            fmap2 = F.avg_pool2d(fmap2, 2, stride=2)
            self.pyramid.append((fmap1, fmap2))

    def __call__(self, coords):
        coords = coords.permute(0, 2, 3, 1)
        B, H, W, _ = coords.shape
        dim = self.pyramid[0][0].shape[1]

        corr_list = []
        for i in range(self.num_levels):
            r = self.radius
            fmap1_i = self.pyramid[0][0].permute(0, 2, 3, 1).contiguous()
            fmap2_i = self.pyramid[i][1].permute(0, 2, 3, 1).contiguous()

            coords_i = (coords / 2 ** i).reshape(B, 1, H, W, 2).contiguous()
            corr, = alt_cuda_corr.forward(fmap1_i, fmap2_i, coords_i, r)
            corr_list.append(corr.squeeze(1))

        corr = torch.stack(corr_list, dim=1)
        corr = corr.reshape(B, -1, H, W)
        return corr / torch.sqrt(torch.tensor(dim).float())


class AlternateCorrBlockv2:
    def __init__(self, fmap1, fmap2, num_levels=4, radius=4):
        self.num_levels = num_levels
        self.radius = radius
        self.lidar_feature = fmap1.unsqueeze(2)
        self.pyramid = [fmap2]
        for i in range(self.num_levels - 1):
            fmap2 = F.avg_pool2d(fmap2, 2, stride=2)
            self.pyramid.append(fmap2)

    def __call__(self, coords):  # B N 2
        dim = self.pyramid[0].shape[1]

        r = self.radius
        corr_list = []
        dx = torch.linspace(-r, r, 2 * r + 1, device=coords.device)
        dy = torch.linspace(-r, r, 2 * r + 1, device=coords.device)
        delta = torch.stack(torch.meshgrid(dy, dx), axis=-1)
        delta_lvl = delta.view(1, 2 * r + 1, 2 * r + 1, 2)
        batch, N, _ = coords.shape

        for i in range(self.num_levels):
            centroid_lvl = coords.reshape(-1, 1, 1, 2) / 2 ** i
            fmap2_i = self.pyramid[i]
            coords_lvl = centroid_lvl + delta_lvl
            coords_lvl = coords_lvl.view(batch, N, (2 * r + 1) * (2 * r + 1), 2)
            H, W = fmap2_i.shape[-2:]
            xgrid, ygrid = coords_lvl.split([1, 1], dim=-1)
            xgrid = 2 * xgrid / (W - 1) - 1
            ygrid = 2 * ygrid / (H - 1) - 1

            grid = torch.cat([xgrid, ygrid], dim=-1).float()
            corr_result = F.grid_sample(fmap2_i, grid, align_corners=True).permute(0, 2, 3, 1)
            corr_result = self.lidar_feature * corr_result
            corr_result = corr_result.sum(dim=-1)
            corr_list.append(corr_result)

        corr = torch.stack(corr_list, dim=2)
        corr = corr.reshape(batch, N, -1)
        return corr / torch.sqrt(torch.tensor(dim).float())
