import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_scatter
from .update import BasicUpdateBlock, SmallUpdateBlock
from .extractor import BasicEncoder, SmallEncoder
from .corr import CorrBlock, CorrBlockv2, AlternateCorrBlock, AlternateCorrBlockv2
from .utils import bilinear_sampler, coords_grid, upflow8, quat2mat_batch, tvector2mat_batch
from .LCCNet import bilinear_interpolate_torch
import torchvision.models as models
import cv2 as cv
import copy
try:
    autocast = torch.cuda.amp.autocast
except:
    # dummy autocast for PyTorch < 1.6
    class autocast:
        def __init__(self, enabled):
            pass

        def __enter__(self):
            pass

        def __exit__(self, *args):
            pass


class RAFT(nn.Module):
    def __init__(self, args):
        super(RAFT, self).__init__()
        self.args = args
        self.iters = args['iters']
        if args['small']:
            self.hidden_dim = hdim = 96
            self.context_dim = cdim = 64
            self.args['corr_levels'] = 4
            self.args['corr_radius'] = 3
        else:
            self.hidden_dim = hdim = 128
            self.context_dim = cdim = 128
            self.args['corr_levels'] = 4
            self.args['corr_radius'] = 4

        if 'dropout' not in self.args.keys():
            self.args['dropout'] = 0

        if 'alternate_corr' not in self.args.keys():
            self.args['dropout'] = False


        # feature network, context network, and update block 64 128
        remove_module = nn.Sequential()
        resnets = models.resnet18(weights = True)
        resnets.bn1 = nn.InstanceNorm2d(64)
        resnets.layer1._modules['0'].bn1 = nn.InstanceNorm2d(64)
        resnets.layer1._modules['0'].bn2 = nn.InstanceNorm2d(64)
        resnets.layer1._modules['1'].bn1 = nn.InstanceNorm2d(64)
        resnets.layer1._modules['1'].bn2 = nn.InstanceNorm2d(64)

        resnets.layer2._modules['0'].bn1 = nn.InstanceNorm2d(128)
        resnets.layer2._modules['0'].bn2 = nn.InstanceNorm2d(128)
        resnets.layer2._modules['1'].bn1 = nn.InstanceNorm2d(128)
        resnets.layer2._modules['1'].bn2 = nn.InstanceNorm2d(128)
        resnets.layer2._modules['0'].downsample._modules['1'] = nn.InstanceNorm2d(128)

        resnets.layer3._modules['0'].bn1 = nn.InstanceNorm2d(256)
        resnets.layer3._modules['0'].bn2 = nn.InstanceNorm2d(256)
        resnets.layer3._modules['1'].bn1 = nn.InstanceNorm2d(256)
        resnets.layer3._modules['1'].bn2 = nn.InstanceNorm2d(256)
        resnets.layer3._modules['0'].downsample._modules['1'] = nn.InstanceNorm2d(256)

        resnets.layer4._modules['0'].bn1 = nn.InstanceNorm2d(512)
        resnets.layer4._modules['0'].bn2 = nn.InstanceNorm2d(512)
        resnets.layer4._modules['1'].bn1 = nn.InstanceNorm2d(512)
        resnets.layer4._modules['1'].bn2 = nn.InstanceNorm2d(512)
        resnets.layer4._modules['0'].downsample._modules['1'] = nn.InstanceNorm2d(512)
        resnets.fc = remove_module
        resnets.avgpool = remove_module

        if self.args['small']:
            # self.fnet = SmallEncoder(output_dim=128, norm_fn='instance')
            # self.fnet_lidar = SmallEncoder(output_dim=128, norm_fn='instance')
            self.conv_first = nn.Conv2d(3,3,kernel_size=(3,3),stride=2,padding=1)
            self.conv_first_lidar = nn.Conv2d(3,3,kernel_size=(3,3),stride=2,padding=1)
            self.fnet = resnets
            self.fnet_lidar = copy.deepcopy(resnets)
            self.cnet = SmallEncoder(output_dim=hdim + cdim, norm_fn='instance')
            self.update_block = SmallUpdateBlock(self.args, hidden_dim=hdim)
        else:
            self.fnet = BasicEncoder(output_dim=256, norm_fn='instance')
            self.fnet_lidar = SmallEncoder(output_dim=128, norm_fn='instance')
            self.cnet = BasicEncoder(output_dim=hdim + cdim, norm_fn='batch')
            self.update_block = BasicUpdateBlock(self.args, hidden_dim=hdim)

        self.init_qt = nn.Sequential(
            nn.Conv2d(120, 96, kernel_size = (3,3), stride = 1, padding = 1),
            nn.InstanceNorm2d(96),
            nn.ReLU(),
            nn.Conv2d(96, 64, kernel_size=(3, 3), stride=1, padding=1),
            nn.InstanceNorm2d(96),
            nn.ReLU(),
            nn.Conv2d(64, 32, kernel_size=(3, 3), stride=1, padding=1),
            nn.InstanceNorm2d(32),
            nn.ReLU()
        )
        self.leakyRELU = nn.LeakyReLU(0.1)
        self.fc = nn.Linear(3840, 512)

        self.fc2_trasl = nn.Linear(512, 3)
        self.fc2_rot = nn.Linear(512, 4)

    def freeze_bn(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                m.eval()

    def initialize_flow(self, img):
        """ Flow is represented as difference between two coordinate grids flow = coords1 - coords0"""
        N, C, H, W = img.shape
        coords0 = coords_grid(N, H // 8, W // 8, device=img.device)
        coords1 = coords_grid(N, H // 8, W // 8, device=img.device)

        # optical flow computed as difference: flow = coords1 - coords0
        return coords0, coords1

    def upsample_flow(self, flow, mask):
        """ Upsample flow field [H/8, W/8, 2] -> [H, W, 2] using convex combination """
        N, _, H, W = flow.shape
        mask = mask.view(N, 1, 9, 8, 8, H, W)
        mask = torch.softmax(mask, dim=2)

        up_flow = F.unfold(8 * flow, [3, 3], padding=1)
        up_flow = up_flow.view(N, 2, 9, 1, 1, H, W)

        up_flow = torch.sum(mask * up_flow, dim=2)
        up_flow = up_flow.permute(0, 1, 4, 2, 5, 3)
        return up_flow.reshape(N, 2, 8 * H, 8 * W)

    def project(self, flow_map, corr_map, corr, flow, B, h, w, uv1, mask_new):
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        uv_new_index = (4 * uv1).long()
        B_channel = torch.arange(0, B).cuda().unsqueeze(-1).unsqueeze(-1).expand(-1, uv_new_index.shape[1], -1).long()
        uv_new_index = torch.cat([B_channel, uv_new_index], dim=-1).view(-1, 3)  # 索引位置 BN 3

        valid_uv_new_index = uv_new_index[mask_new, :]  # 新位置的index
        valid_index = valid_uv_new_index[:, 0] * h * w + valid_uv_new_index[:, 2] * w + valid_uv_new_index[:, 1]
        valid_unq_coords, valid_unq_coords_inv, _ = torch.unique(valid_index, return_inverse=True,
                                                                 return_counts=True,
                                                                 dim=0)

        # 在同一个新位置的特征用平均处理[mask_new, :]
        B_valid = valid_unq_coords // (h * w)
        H_valid = (valid_unq_coords % (h * w)) // w
        W_valid = valid_unq_coords % w
        corr = corr.view(-1, corr.shape[-1])
        flow = flow.view(-1, flow.shape[-1])
        corr = corr[mask_new,:]
        flow = flow[mask_new,:]

        valid_avg_feature = torch_scatter.scatter_mean(corr, valid_unq_coords_inv, dim=0)
        flow = torch_scatter.scatter_mean(flow, valid_unq_coords_inv, dim=0)
        # start.record()
        corr_map[B_valid, :, H_valid, W_valid] = valid_avg_feature
        # corr_show = corr_map[0]
        # corr_show = corr_show.sum(dim = 0)
        # corr_show = corr_show.detach().cpu().numpy().astype(np.uint8)
        # cv.imshow("1",corr_show)
        # cv.waitKey(0)
        flow_map[B_valid, :, H_valid, W_valid] = flow.float()
        # corr_map = corr_map.detach()
        # end.record()
        # torch.cuda.synchronize()
        # print("4.0")
        # print(start.elapsed_time(end))

        return corr_map, flow_map

    def forward(self, sample):
        """ Estimate optical flow between pair of frames """
        # start = torch.cuda.Event(enable_timing=True)
        # end = torch.cuda.Event(enable_timing=True)

        # start.record()
        rgb, lidar, uv, pcl_xyz, mask, K = sample['rgb'].cuda(), sample['lidar_input'].cuda(), \
            sample['uv'].cuda(), sample['pcl_xyz'].cuda(), sample['mask'].cuda(), sample['calib'].cuda().float()
        rgb = 2 * (rgb / 255.0) - 1.0

        B, _, H, W = rgb.shape
        rgb = rgb.contiguous()
        lidar = lidar.contiguous()

        hdim = self.hidden_dim
        cdim = self.context_dim

        # run the feature network
        fmap1 = self.conv_first(rgb)
        fmap1 = self.fnet.conv1(fmap1)  # B，64，128，256
        fmap1 = self.fnet.bn1(fmap1)  # B，64，128，256
        fmap1 = self.fnet.relu(fmap1)  # 1，64，128，256
        # self.features.append(self.encoder.layer1(self.encoder.maxpool(self.features[-1])))
        features = []
        fmap1 = self.fnet.maxpool(fmap1)  # POOL
        features.append(self.fnet.layer1(fmap1))  # 32，64，64，128
        features.append(self.fnet.layer2(features[-1]))  # 32，128，32，64
        features.append(self.fnet.layer3(features[-1]))  # 32，256，16，32
        features.append(self.fnet.layer4(features[-1]))  # 32，512，8，16

        fmap2 = self.conv_first_lidar(lidar)
        fmap2 = self.fnet_lidar.conv1(fmap2)  # B，64，128，256
        fmap2 = self.fnet_lidar.bn1(fmap2)  # B，64，128，256
        fmap2 = self.fnet_lidar.relu(fmap2)  # 1，64，128，256
        # self.features.append(self.encoder.layer1(self.encoder.maxpool(self.features[-1])))
        features2 = []
        fmap2 = self.fnet_lidar.maxpool(fmap2)  # POOL
        features2.append(self.fnet_lidar.layer1(fmap2))  # 32，64，48，160
        features2.append(self.fnet_lidar.layer2(features2[-1]))  # 32，128，24，80
        features2.append(self.fnet_lidar.layer3(features2[-1]))  # 32，256，12，40
        features2.append(self.fnet_lidar.layer4(features2[-1]))  # 32，512，6，20

        fmap1 = fmap1.float()
        fmap2 = fmap2.float()
        uv0 = uv / 8
        uv1 = uv / 8
        # end.record()
        # torch.cuda.synchronize()
        # print("1")
        # print(start.elapsed_time(end))

        # start.record()
        if self.args['alternate_corr']:
            corr_fn = CorrBlockv2(features, features2, uv0, radius=self.args['corr_radius'])
        else:
            corr_fn = CorrBlock(fmap1, fmap2, radius=self.args['corr_radius'])
        # end.record()
        # torch.cuda.synchronize()
        # print("2")
        # print(start.elapsed_time(end))
        # start.record()
        # run the context network
        cnet = self.cnet(lidar)
        net, inp = torch.split(cnet, [hdim, cdim], dim=1)
        net = torch.tanh(net)
        inp = torch.relu(inp)
        # coords0, coords1 = self.initialize_flow(rgb)  # B N C

        qt = []
        mask_new = mask.clone()
        mask_new2 = mask.clone()
        h, w = H//2, W//2
        RT_target0 = torch.eye(4, 4, dtype = torch.float32).cuda().unsqueeze(0)
        RT_target0 = RT_target0.repeat(B,1,1)
        valid_list = torch.zeros(uv.shape[0], self.iters + 1, dtype=torch.bool).cuda()
        valid_list[:,0] = True
        q_ = torch.zeros(4, dtype=torch.float32).cuda()
        q_[0] = 1
        t_ = torch.zeros(3, dtype=torch.float32).cuda()

        hd, wd, B = H // 64, W // 64, uv.shape[0]
        deep_feature = corr_fn.corr_pyramid[-1].view(B,hd,wd,-1).permute(0,3,1,2)
        deep_feature = self.init_qt(deep_feature)
        x = deep_feature.view(B,-1)
        x = self.leakyRELU(self.fc(x))
        t = self.fc2_trasl(x)
        q = self.fc2_rot(x)
        q = F.normalize(q, dim=1)

        # q[0,:] = q_.clone()
        # t[0,:] = t_.clone()

        R_target = quat2mat_batch(q)
        T_target = tvector2mat_batch(t)
        RT_target = torch.bmm(T_target, R_target)
        qt.append(RT_target)
        RT_target0 = RT_target.clone()
        pcl_xyz_now = torch.bmm(RT_target.detach(), pcl_xyz).float()  # 现在到gt
        mask_new2 = pcl_xyz_now[:, 2, :] > 1e-6
        uv1 = torch.bmm(K, pcl_xyz_now[:, 0:3, :])
        temp = uv1[:, 2, :].clone()
        temp = torch.clamp(temp, 1e-6)
        uv1[:, 0, :] = uv1[:, 0, :].clone() / temp
        uv1[:, 1, :] = uv1[:, 1, :].clone() / temp
        uv1 = uv1[:, 0:2, :].permute(0, 2, 1)
        uv1 = uv1.detach() / 8
        # end.record()
        # torch.cuda.synchronize()
        # print("3")
        # print(start.elapsed_time(end))

        for itr in range(0, self.iters):

            corr = corr_fn(uv1).contiguous() # B N C
            flow = (uv1 - uv0).contiguous()  # B N C
            mask_new = (uv1[:, :, 0] < W / 8) & (uv1[:, :, 0] >= 0) & \
                        (uv1[:, :, 1] < H / 8) & (uv1[:, :, 1] >= 0)  # BN
            mask_new = (mask_new2 * mask_new * mask)

            if(itr < self.iters):
                valid_iter = (mask_new.int().sum(dim=1) > 5)
                valid_list[:, itr + 1] = valid_iter * valid_list[:, itr]
            mask_new = mask_new.view(-1)
            # start.record()
            corr_map, flow_map = self.project(sample['flows'][itr], sample['corr_map'][itr], corr, flow, B, h, w, uv0, mask_new)#太慢
            # end.record()
            # torch.cuda.synchronize()
            # print("3")
            # print(start.elapsed_time(end))
            # start.record()

            # motionencoder 将 corr 和 flow 转化到 W/2 H/2 尺寸上 DWconv 转化得到 W/8 H/8 160 48 GRU以后 downsample 转化为 20 6
            with autocast(enabled=self.args['mixed_precision']):
                net, q, t = self.update_block(net, inp, corr_map, flow_map)
            # q[0,:] = q_.clone()
            # t[0,:] = t_.clone()
            q[~valid_list[:, itr+1], :] = q_
            t[~valid_list[:, itr+1], :] = t_
            # end.record()
            # torch.cuda.synchronize()
            # print("4")
            # print(start.elapsed_time(end))
            # start.record()

            # q t -> rigid flow
            R_target = quat2mat_batch(q)
            T_target = tvector2mat_batch(t)
            RT_target = torch.bmm(T_target, R_target)
            RT_target = torch.bmm(RT_target, RT_target0)

            pcl_xyz_now = torch.bmm(RT_target.detach(), pcl_xyz).float()  # 现在到gt
            mask_new2 = pcl_xyz_now[:, 2, :] > 1e-6
            # 新的uv
            uv1 = torch.bmm(K, pcl_xyz_now[:, 0:3, :])
            temp = uv1[:, 2, :].clone()
            temp = torch.clamp(temp, 1e-6)
            uv1[:, 0, :] = uv1[:, 0, :].clone() / temp
            uv1[:, 1, :] = uv1[:, 1, :].clone() / temp
            uv1 = uv1[:, 0:2, :].permute(0, 2, 1)
            uv1 = uv1.detach()/8

            RT_target0 = RT_target.detach().clone()
            qt.append(RT_target)
            # end.record()
            # torch.cuda.synchronize()
            # print("5")
            # print(start.elapsed_time(end))
            # print("6")
        # print('\n')
        # print(valid_list)

        return qt, valid_list
