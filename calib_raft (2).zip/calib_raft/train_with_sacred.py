import torch.multiprocessing
import ssl

ssl._create_default_https_context = ssl._create_unverified_context
torch.multiprocessing.set_sharing_strategy('file_system')
from logger import *
import math
import os
import random
import time
from tqdm import tqdm
from models.raft import RAFT
# import apex
import numpy as np
import torch.nn.functional as F
import torch.nn.parallel
import torch.optim as optim
import torch.utils.data
import torch.nn as nn

from DatasetLidarCamera import DatasetLidarCameraKittiOdometry
from losses import DistancePoints3D, GeometricLoss, L1Loss, ProposedLoss, CombinedLoss, qtloss
from models.LCCNet import LCCNet
import datetime
from torch.utils.tensorboard import SummaryWriter
from quaternion_distances import quaternion_distance
import torch
import yaml
from utils import (merge_inputs)

torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = False
os.environ['CUDA_VISIBLE_DEVICES'] = "1"
EPOCH = 1
def _init_fn(worker_id, seed):
    seed = seed + worker_id + EPOCH * 100
    INFO(f"Init worker {worker_id} with seed {seed}")
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

# CCN training
def train(model, optimizer, loss_fn, sample):
    model.train()
    optimizer.zero_grad()
    # Run model
    qts, valid_list = model(sample)  # BCWH   B C   W H   B N 2   B N 3   B N 1

    model_end = time.time()
    losses, totalloss  = loss_fn(sample['tr_error'], sample['rot_error'], qts, valid_list,sample['mask'].cuda(), sample['pcl_xyz'].cuda())
    loss_end = time.time()
    DEBUG(f'loss time cost :{loss_end - model_end}')
    totalloss.backward()
    optimizer.step()

    return totalloss, losses


# CNN test
def val(model, rgb_img, refl_img, target_transl, target_rot,
        uv, uv_gt, pcl_xyz, mask, loss_fn, point_clouds, loss, K):
    model.eval()

    # Run model
    with torch.no_grad():
        T_dist, sparse_flow = model(rgb_img, refl_img, uv, pcl_xyz, mask, K)

    if loss == 'points_distance' or loss == 'combined':
        losses = loss_fn(point_clouds, target_transl, target_rot, T_dist[:, 3, 0:3], T_dist[:, 0:3, 0:3])
        losses = 0.25 * torch.abs(sparse_flow - (uv - uv_gt)).mean() + losses
    else:
        losses = loss_fn(target_transl, target_rot, T_dist[:, 3, 0:3], T_dist[:, 0:3, 0:3])


    total_trasl_error = torch.tensor(0.0).cuda()
    total_rot_error = quaternion_distance(target_rot, T_dist[:, 0:3, 0:3], target_rot.device)
    total_rot_error = total_rot_error * 180. / math.pi
    for j in range(rgb_img.shape[0]):
        total_trasl_error += torch.norm(target_transl[j] - T_dist[:, 3, 0:3][j]) * 100.

    return losses, total_trasl_error.item(), total_rot_error.sum().item(), T_dist[:, 0:3, 0:3], T_dist[:, 3, 0:3]


def worker_init_fn(worker_id):
    random.seed(1234 + worker_id)

if __name__ == '__main__':
    yaml_path = "D:/calib_raft/scratch.yml"
    with open(yaml_path, "r", encoding="utf-8") as f:
        _config = yaml.load(f, Loader=yaml.FullLoader)

    import torch

    if _config['val_sequence'] is None:
        raise TypeError('val_sequences cannot be None')
    else:
        _config['val_sequence'] = f"{_config['val_sequence']:02d}"
        INFO("Val Sequence: {}".format(_config['val_sequence']))
        dataset_class = DatasetLidarCameraKittiOdometry
    img_shape = (384, 1280)  # 网络的输入尺度
    input_size = (128, 512)
    _config["checkpoints"] = os.path.join(_config["checkpoints"], _config['dataset'])
    ratio = _config["ratio"]
    dataset_train = dataset_class(_config['data_folder'], max_r=_config['max_r'], max_t=_config['max_t'],
                                  split='train', use_reflectance=_config['use_reflectance'], ratio=ratio,
                                  val_sequence=_config['val_sequence'], config=_config, img_shape=img_shape,
                                  max_points=_config['max_points'], input_size=input_size)
    dataset_val = dataset_class(_config['data_folder'], max_r=_config['max_r'], max_t=_config['max_t'],
                                split='val', use_reflectance=_config['use_reflectance'],
                                val_sequence=_config['val_sequence'], config=_config, img_shape=img_shape,
                                max_points=_config['max_points'], input_size=input_size)
    model_savepath = os.path.join(_config['checkpoints'], 'val_seq_' + _config['val_sequence'], 'models')
    if not os.path.exists(model_savepath):
        os.makedirs(model_savepath)  # 1220 142


    train_dataset_size = len(dataset_train)
    val_dataset_size = len(dataset_val)
    INFO('Number of the train dataset: {}'.format(train_dataset_size))
    INFO('Number of the val dataset: {}'.format(val_dataset_size))

    # Training and validation set creation
    num_worker = _config['num_worker']
    batch_size = _config['batch_size']
    TrainImgLoader = torch.utils.data.DataLoader(dataset=dataset_train,
                                                 shuffle=True,
                                                 batch_size=batch_size,
                                                 num_workers=num_worker,
                                                 worker_init_fn=worker_init_fn,
                                                 collate_fn=merge_inputs,
                                                 drop_last=False,
                                                 pin_memory=True)
    INFO(len(TrainImgLoader))

    loss_fn = qtloss(_config['rescale_transl'], _config['rescale_rot'])

    # network choice and settings
    model = RAFT(_config['network_config'])

    if _config['weights'] is not None:
        INFO(f"Loading weights from {_config['weights']}")
        checkpoint = torch.load(_config['weights'], map_location='cuda')
        saved_state_dict = checkpoint['state_dict']
        new_state_dict = {}
        for k, v in saved_state_dict.items():
            if 'bn' not in k:
                new_state_dict[k] = v
        model.load_state_dict(new_state_dict)
    if _config['multi_gpu']:
        model = nn.DataParallel(model)
    model = model.cuda()
    print(model)
    INFO('Number of model parameters: {}'.format(sum([p.data.nelement() for p in model.parameters()])))
    parameters = list(filter(lambda p: p.requires_grad, model.parameters()))

    if _config['optimizer'] == 'adam':
        optimizer = optim.Adam(parameters, lr=_config['BASE_LEARNING_RATE'], weight_decay=5e-6)


    starting_epoch = _config['starting_epoch']
    if _config['weights'] is not None and _config['resume']:
        checkpoint = torch.load(_config['weights'], map_location='cuda')
        starting_epoch = checkpoint['epoch']
        opt_state_dict = checkpoint['optimizer']
        optimizer.load_state_dict(opt_state_dict)
    # if starting_epoch != 0:
    # starting_epoch = checkpoint['epoch']

    # Allow mixed-precision if needed
    # model, optimizer = apex.amp.initialize(model, optimizer, opt_level=_config["precision"])

    start_full_time = time.time()
    BEST_VAL_LOSS = 10000.
    old_save_filename = None

    train_iter = 0
    val_iter = 0
    runs = datetime.datetime.now().strftime('%b%d_%H-%M-%S') + "/"
    train_writer = SummaryWriter('./logs/' + runs)

    flows = []
    corr_map = []
    B, C, H, W = _config['batch_size'], _config['network_config']['C'], \
        _config['network_config']['H'], _config['network_config']['W']
    for i in range(_config['network_config']['iters']):
        flows.append(torch.zeros([B, 2, H, W], dtype=torch.float32).cuda())
        corr_map0 = torch.zeros([B, C, H, W], dtype=torch.float32).cuda()
        corr_map.append(corr_map0)

    for epoch in range(starting_epoch, _config['epochs'] + 1):

        INFO('This is %d-th epoch' % epoch)
        epoch_start_time = time.time()
        total_train_loss = 0
        local_loss = 0.
        aver_flow_loss = 0.

        ## Training ##
        time_for_50ep = time.time()
        total_iter_start = time.time()
        pbar = tqdm(iterable=enumerate(TrainImgLoader), total=len(TrainImgLoader), desc='train', leave=False, ncols=150)
        pbar.set_description('epoch: {}/{}'.format(epoch, _config['epochs']))
        for batch_idx, sample in pbar:
            start_time = time.time()
            # gt pose
            sample['tr_error'] = sample['tr_error'].cuda()
            sample['rot_error'] = sample['rot_error'].cuda()
            sample['lidar_input'] = sample['lidar_input'].cuda()
            rgb_input = sample['rgb_input'].cuda()

            sample['flows'] = []
            sample['corr_map'] = []
            if rgb_input.shape[0] != _config['batch_size']:
                for i in range(_config['network_config']['iters']):
                    sample['flows'].append( flows[i][0:rgb_input.shape[0],:,:,:].clone())
                    sample['corr_map'].append( corr_map[i][0:rgb_input.shape[0],:,:,:].clone())
            else:
                sample['flows'] = flows
                sample['corr_map'] = corr_map
            # rgb_input = F.interpolate(rgb_input, size=[384, 1280], mode="bilinear")
            sample['rgb'] = rgb_input
            end_preprocess = time.time()
            total_loss, loss = train(model, optimizer, loss_fn, sample)

            for i in range(_config['network_config']['iters']):#清除中间变量的梯度,清零
                flows[i] = flows[i].detach()
                corr_map[i] = corr_map[i].detach()
                flows[i][:, :, :, :] = 0
                corr_map[i][:, :, :, :] = 0

            total_iter_start = time.time()
            local_loss += total_loss.item()
            disp_dict = {'total_loss': total_loss.item(), 'fl6': loss[0].item(),
                        'fl5': loss[1].item(), 'fl4': loss[2].item(),
                        'fl3': loss[3].item(), 'fl2': loss[4].item()}

            pbar.set_postfix(disp_dict)
            pbar.update()
            pbar.refresh()
            if batch_idx % 50 == 0 and batch_idx != 0:
                INFO(f'Iter {batch_idx}/{len(TrainImgLoader)} training loss = {local_loss / 50:.3f}, '
                     f'time for 50 iter: {time.time() - time_for_50ep:.4f}')
                time_for_50ep = time.time()
                train_writer.add_scalar("batch training loss", local_loss / 50, train_iter)
                local_loss = 0.

            total_train_loss += total_loss.item() * len(sample['rgb'])
            train_iter += 1

        INFO("------------------------------------")
        INFO('epoch %d total training loss = %.3f' % (epoch, total_train_loss / len(dataset_train)))
        INFO('Total epoch time = %.2f' % (time.time() - epoch_start_time))
        INFO("------------------------------------")
        train_writer.add_scalar("total training loss", total_train_loss / len(dataset_train), epoch)

        if (epoch % 10 == 0):
            savefilename = f'{model_savepath}/checkpoint_r_e{epoch}.tar'
            aver_flow_loss /= train_dataset_size
            if _config['multi_gpu']:
                torch.save({
                    'config': _config,
                    'epoch': epoch,
                    # 'state_dict': model.state_dict(), # single gpu
                    'state_dict': model.module.state_dict(),  # multi gpu
                    'optimizer': optimizer.state_dict(),
                }, savefilename, _use_new_zipfile_serialization=True)
            else:
                torch.save({
                    'config': _config,
                    'epoch': epoch,
                    'state_dict': model.state_dict(), # single gpu
                    # 'state_dict': model.module.state_dict(),  # multi gpu
                    'optimizer': optimizer.state_dict(),
                }, savefilename, _use_new_zipfile_serialization=True)

    INFO('full training time = %.2f HR' % ((time.time() - start_full_time) / 3600))
