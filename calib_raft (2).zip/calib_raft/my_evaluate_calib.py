# -------------------------------------------------------------------
# Copyright (C) 2020 Università degli studi di Milano-Bicocca, iralab
# Author: Daniele Cattaneo (d.cattaneo10@campus.unimib.it)
# Released under Creative Commons
# Attribution-NonCommercial-ShareAlike 4.0 International License.
# http://creativecommons.org/licenses/by-nc-sa/4.0/
# -------------------------------------------------------------------

# Modified Author: Xudong Lv
# based on github.com/cattaneod/CMRNet/blob/master/evaluate_iterative_single_CALIB.py

import csv
# import matplotlib
# matplotlib.use('Qt5Agg')
import os
import random
import time
import yaml
import cv2
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn.functional as F
import torch.nn.parallel
import torch.utils.data
from sacred import Experiment
from sacred.utils import apply_backspaces_and_linefeeds
from tqdm import tqdm
from models.raft import RAFT
from DatasetLidarCamera import DatasetLidarCameraKittiOdometry
from models.LCCNet import LCCNet
from quaternion_distances import quaternion_distance
from utils import (mat2xyzrpy, merge_inputs, overlay_imgs, quat2mat,
                   quaternion_from_matrix, rotate_back, rotate_forward,
                   tvector2mat,tvector2mat_batch,quat2mat_batch)
from losses import qtloss
# import matplotlib
# matplotlib.rc("font",family='AR PL UMing CN')
plt.rcParams['axes.unicode_minus'] = False
# plt.rc('font',family='Times New Roman')
font_EN = {'family': 'Times New Roman', 'weight': 'normal', 'size': 16}
font_CN = {'family': 'AR PL UMing CN', 'weight': 'normal', 'size': 16}
plt_size = 10.5

ex = Experiment("LCCNet-evaluate-iterative",save_git_info=False)
ex.captured_out_filter = apply_backspaces_and_linefeeds
# os.environ['CUDA_VISIBLE_DEVICES'] = '1'

device = "cuda"  # torch.device(#if torch.cuda.is_available() else "cpu")

EPOCH = 1


def _init_fn(worker_id, seed):
    seed = seed + worker_id + EPOCH * 100
    print(f"Init worker {worker_id} with seed {seed}")
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)


def get_2D_lidar_projection(pcl, cam_intrinsic):
    pcl_xyz = cam_intrinsic @ pcl.T
    pcl_xyz = pcl_xyz.T
    pcl_z = pcl_xyz[:, 2]
    pcl_xyz = pcl_xyz / (pcl_xyz[:, 2, None] + 1e-10)
    pcl_uv = pcl_xyz[:, :2]

    return pcl_uv, pcl_z


def lidar_project_depth(pc_rotated, cam_calib, img_shape):
    pc_rotated = pc_rotated[:3, :].detach().cpu().numpy()
    cam_intrinsic = cam_calib.numpy()
    pcl_uv, pcl_z = get_2D_lidar_projection(pc_rotated.T, cam_intrinsic)
    mask = (pcl_uv[:, 0] > 0) & (pcl_uv[:, 0] < img_shape[1]) & (pcl_uv[:, 1] > 0) & (
            pcl_uv[:, 1] < img_shape[0]) & (pcl_z > 0)
    pcl_uv = pcl_uv[mask]
    pcl_z = pcl_z[mask]
    pcl_uv = pcl_uv.astype(np.uint32)
    pcl_z = pcl_z.reshape(-1, 1)
    depth_img = np.zeros((img_shape[0], img_shape[1], 1))
    depth_img[pcl_uv[:, 1], pcl_uv[:, 0]] = pcl_z
    depth_img = torch.from_numpy(depth_img.astype(np.float32))
    depth_img = depth_img.cuda()
    depth_img = depth_img.permute(2, 0, 1)
    pc_valid = pc_rotated.T[mask]

    return depth_img, pcl_uv, pc_valid

def worker_init_fn(worker_id):
    random.seed(1234 + worker_id)

def last_T(qt_all):
    q6, t6, q5, t5, q4, t4, q3, t3, q2, t2 = qt_all
    R_predicted = quat2mat_batch(q6)
    T_predicted = tvector2mat_batch(t6)
    RT_predicted = torch.bmm(T_predicted, R_predicted)

    R_predicted = quat2mat_batch(q5)
    T_predicted = tvector2mat_batch(t5)
    RT_predicted = torch.bmm(torch.bmm(T_predicted, R_predicted),RT_predicted)

    R_predicted = quat2mat_batch(q4)
    T_predicted = tvector2mat_batch(t4)
    RT_predicted = torch.bmm(torch.bmm(T_predicted, R_predicted),RT_predicted)

    R_predicted = quat2mat_batch(q3)
    T_predicted = tvector2mat_batch(t3)
    RT_predicted = torch.bmm(torch.bmm(T_predicted, R_predicted),RT_predicted)

    # R_predicted = quat2mat_batch(q2)
    # T_predicted = tvector2mat_batch(t2)
    # RT_predicted = torch.bmm(torch.bmm(T_predicted, R_predicted),RT_predicted)
    return RT_predicted
@ex.automain
def main(_config, seed):
    yaml_path = "D:/calib_raft/scratch.yml"
    with open(yaml_path, "r", encoding="utf-8") as f:
        _config = yaml.load(f, Loader=yaml.FullLoader)

    global EPOCH, weights
    weights = _config['weights']
    dataset_class = DatasetLidarCameraKittiOdometry
    img_shape = (384, 1280)
    _config['test_sequence'] = f"{_config['test_sequence']:02d}"
    dataset_val = dataset_class(_config['data_folder'], max_r=_config['max_r'], max_t=_config['max_t'],
                                    split='test', use_reflectance=_config['use_reflectance']
                                    ,config=_config, img_shape=img_shape,val_sequence=_config['test_sequence'])
    np.random.seed(seed)
    torch.random.manual_seed(seed)

    loss_fn = qtloss(2, 1)
    num_worker = 6
    batch_size = 8
    TestImgLoader = torch.utils.data.DataLoader(dataset=dataset_val,
                                                shuffle=False,
                                                batch_size=batch_size,
                                                num_workers=num_worker,
                                                worker_init_fn=worker_init_fn,
                                                collate_fn=merge_inputs,
                                                drop_last=False,
                                                pin_memory=False)

    print(len(TestImgLoader))

    models = []  # iterative model
    # for i in range(len(weights)):#初始化所有的权重
        # network choice and settings
    model = RAFT(_config['network_config'])
    checkpoint = torch.load(weights, map_location='cpu')
    saved_state_dict = checkpoint['state_dict']
    model.load_state_dict(saved_state_dict)
    model = model.to(device)
    model.train()
    models.append(model)

    # save image to the output path
    _config['output'] = os.path.join(_config['output'], _config['iterative_method'])
    rgb_path = os.path.join(_config['output'], 'rgb')
    if not os.path.exists(rgb_path):
        os.makedirs(rgb_path)
    depth_path = os.path.join(_config['output'], 'depth')
    if not os.path.exists(depth_path):
        os.makedirs(depth_path)
    input_path = os.path.join(_config['output'], 'input')
    if not os.path.exists(input_path):
        os.makedirs(input_path)
    gt_path = os.path.join(_config['output'], 'gt')
    if not os.path.exists(gt_path):
        os.makedirs(gt_path)
    if _config['out_fig_lg'] == 'EN':
        results_path = os.path.join(_config['output'], 'results_en')
    elif _config['out_fig_lg'] == 'CN':
        results_path = os.path.join(_config['output'], 'results_cn')
    if not os.path.exists(results_path):
        os.makedirs(results_path)
    pred_path = os.path.join(_config['output'], 'pred')
    for it in range(len(weights)):
        if not os.path.exists(os.path.join(pred_path, 'iteration_' + str(it + 1))):
            os.makedirs(os.path.join(pred_path, 'iteration_' + str(it + 1)))

    # save pointcloud to the output path
    pc_lidar_path = os.path.join(_config['output'], 'pointcloud', 'lidar')
    if not os.path.exists(pc_lidar_path):
        os.makedirs(pc_lidar_path)
    pc_input_path = os.path.join(_config['output'], 'pointcloud', 'input')
    if not os.path.exists(pc_input_path):
        os.makedirs(pc_input_path)
    pc_pred_path = os.path.join(_config['output'], 'pointcloud', 'pred')
    if not os.path.exists(pc_pred_path):
        os.makedirs(pc_pred_path)

    errors_r = []
    errors_t = []
    errors_t2 = []
    errors_rpy = []
    RTs = []
    total_time = 0

    for i in range(len(weights) + 1):
        errors_r.append([])
        errors_t.append([])
        errors_t2.append([])
        errors_rpy.append([])

    for batch_idx, sample in enumerate(tqdm(TestImgLoader)):

        sample['tr_error'] = sample['tr_error'].cuda()
        sample['rot_error'] = sample['rot_error'].cuda()
        sample['lidar_input'] = sample['lidar_input'].cuda()        # 384 1280 192 640
        rgb_input = sample['rgb_input'].cuda()
        # rgb_input = F.interpolate(rgb_input, size=[192, 640], mode="bilinear")
        sample['rgb'] = rgb_input#20000 4 49

        q_target = sample['rot_error']
        t_target = sample['tr_error']
        R_target = quat2mat_batch(q_target)
        T_target = tvector2mat_batch(t_target)
        RT_target = torch.bmm(T_target, R_target)
        RTs = []
        for i in range(len(weights) + 1):
            RTs.append([])
        for i in range(0, len(sample['rgb'])):
            # the initial calibration errors before sensor calibration

            errors_t[0].append(t_target[i].norm().item())
            errors_t2[0].append(t_target[i])
            errors_r[0].append(quaternion_distance(q_target[i].unsqueeze(0),
                                                   torch.tensor([1., 0., 0., 0.], device=q_target.device).unsqueeze(0),
                                                   q_target[i].device))
            # rpy_error = quaternion_to_tait_bryan(R_composed)
            rpy_error = mat2xyzrpy(RT_target[i])[3:]
            rpy_error *= (180.0 / 3.141592)
            errors_rpy[0].append(rpy_error)
            RTs[0].append(RT_target[i])
        start = 0
        # Run model
        with torch.no_grad():
            sample['uv'], sample['pcl_xyz'], sample['mask'], sample['calib'] =\
                    sample['uv'].cuda(), sample['pcl_xyz'].cuda(), sample['mask'].cuda(), sample['calib'].cuda()

            for iteration in range(start, 1):#len(weights)):
                # Run the i-th network
                t1 = time.time()
                qt_all, valid_list = models[iteration](sample)
                RT_predicted = qt_all[-1]
                run_time = time.time() - t1
                # qt_all = (q6, t6, q5, t5, q4, t4, q3, t3, q2, t2)
                # losses = loss_fn(t_target, q_target, qt_all, valid_list)
                # RT_predicted = last_T(qt_all)
                for i in range(len(sample['rgb'])):
                    # Project the points in the new pose predicted by the i-th network
                    RTs[iteration + 1].append(torch.mm(RTs[iteration][i], RT_predicted[i]))  # inv(H_gt)*H_pred_1*H_pred_2*.....H_pred_n

                    T_composed = RTs[iteration + 1][i][:3, 3]
                    R_composed = quaternion_from_matrix(RTs[iteration + 1][i][0:3, 0:3])
                    errors_t[iteration + 1].append(T_composed.norm().item())
                    errors_t2[iteration + 1].append(T_composed)
                    errors_r[iteration + 1].append(quaternion_distance(R_composed.unsqueeze(0),
                                                                       torch.tensor([1., 0., 0., 0.],
                                                                       device=R_composed.device).unsqueeze(0),
                                                                       R_composed.device))

                    rpy_error = mat2xyzrpy(RTs[iteration + 1][i])
                    rpy_error *= (180.0 / 3.141592)
                    errors_rpy[iteration + 1].append(rpy_error[3:])


        # run_time = time.time() - t1
        total_time += run_time


    # Yaw（偏航）：欧拉角向量的y轴
    # Pitch（俯仰）：欧拉角向量的x轴
    # Roll（翻滚）： 欧拉角向量的z轴
    # mis_calib_input[transl_x, transl_y, transl_z, rotx, roty, rotz] Nx6
    print("Iterative refinement: ")
    for i in range(len(weights) + 1):
        errors_r[i] = torch.abs(torch.tensor(errors_r[i])) * (180.0 / 3.141592)
        errors_t[i] = torch.abs(torch.tensor(errors_t[i])) * 100
        errors_rpy[i] = torch.abs(torch.stack(errors_rpy[i]))
        errors_t2[i] = torch.abs(torch.stack(errors_t2[i])) * 100
        # for k in range(len(errors_rpy[i])):
        #     # errors_rpy[i][k] = torch.tensor(errors_rpy[i][k])
        #     # errors_t2[i][k] = torch.tensor(errors_t2[i][k]) * 100
        #     errors_rpy[i][k] = errors_rpy[i][k].clone().detach().abs()
        #     errors_t2[i][k] = errors_t2[i][k].clone().detach().abs() * 100

        print(f"Iteration {i}: \tMean Translation Error: {errors_t[i].mean():.4f} cm "
              f"     Mean Rotation Error: {errors_r[i].mean():.4f} degree")
        print(f"Iteration {i}: \tMedian Translation Error: {errors_t[i].median():.4f} cm "
              f"     Median Rotation Error: {errors_r[i].median():.4f} degree")
        print(f"Iteration {i}: \tStd. Translation Error: {errors_t[i].std():.4f} cm "
              f"     Std. Rotation Error: {errors_r[i].std():.4f} degree\n")

        # translation xyz
        print(f"Iteration {i}: \tMean Translation X Error: {errors_t2[i][:, 0].mean():.4f} cm "
              f"     Median Translation X Error: {errors_t2[i][:, 0].median():.4f} cm "
              f"     Std. Translation X Error: {errors_t2[i][:, 0].std():.4f} cm ")
        print(f"Iteration {i}: \tMean Translation Y Error: {errors_t2[i][:, 1].mean():.4f} cm "
              f"     Median Translation Y Error: {errors_t2[i][:, 1].median():.4f} cm "
              f"     Std. Translation Y Error: {errors_t2[i][:, 1].std():.4f} cm ")
        print(f"Iteration {i}: \tMean Translation Z Error: {errors_t2[i][:, 2].mean():.4f} cm "
              f"     Median Translation Z Error: {errors_t2[i][:, 2].median():.4f} cm "
              f"     Std. Translation Z Error: {errors_t2[i][:, 2].std():.4f} cm \n")

        # rotation rpy
        print(f"Iteration {i}: \tMean Rotation Roll Error: {errors_rpy[i][:, 0].mean(): .4f} degree"
              f"     Median Rotation Roll Error: {errors_rpy[i][:, 0].median():.4f} degree"
              f"     Std. Rotation Roll Error: {errors_rpy[i][:, 0].std():.4f} degree")
        print(f"Iteration {i}: \tMean Rotation Pitch Error: {errors_rpy[i][:, 1].mean(): .4f} degree"
              f"     Median Rotation Pitch Error: {errors_rpy[i][:, 1].median():.4f} degree"
              f"     Std. Rotation Pitch Error: {errors_rpy[i][:, 1].std():.4f} degree")
        print(f"Iteration {i}: \tMean Rotation Yaw Error: {errors_rpy[i][:, 2].mean(): .4f} degree"
              f"     Median Rotation Yaw Error: {errors_rpy[i][:, 2].median():.4f} degree"
              f"     Std. Rotation Yaw Error: {errors_rpy[i][:, 2].std():.4f} degree\n")

        with open(os.path.join(_config['output'], 'results.txt'),
                  'a', encoding='utf-8') as f:
            f.write(f"Iteration {i}: \n")
            f.write("Translation Error && Rotation Error:\n")
            f.write(f"Iteration {i}: \tMean Translation Error: {errors_t[i].mean():.4f} cm "
                    f"     Mean Rotation Error: {errors_r[i].mean():.4f} degree\n")
            f.write(f"Iteration {i}: \tMedian Translation Error: {errors_t[i].median():.4f} cm "
                    f"     Median Rotation Error: {errors_r[i].median():.4f} degree\n")
            f.write(f"Iteration {i}: \tStd. Translation Error: {errors_t[i].std():.4f} cm "
                    f"     Std. Rotation Error: {errors_r[i].std():.4f} degree\n\n")

            # translation xyz
            f.write("Translation Error XYZ:\n")
            f.write(f"Iteration {i}: \tMean Translation X Error: {errors_t2[i][:, 0].mean():.4f} cm "
                    f"     Median Translation X Error: {errors_t2[i][:, 0].median():.4f} cm "
                    f"     Std. Translation X Error: {errors_t2[i][:, 0].std():.4f} cm \n")
            f.write(f"Iteration {i}: \tMean Translation Y Error: {errors_t2[i][:, 1].mean():.4f} cm "
                    f"     Median Translation Y Error: {errors_t2[i][:, 1].median():.4f} cm "
                    f"     Std. Translation Y Error: {errors_t2[i][:, 1].std():.4f} cm \n")
            f.write(f"Iteration {i}: \tMean Translation Z Error: {errors_t2[i][:, 2].mean():.4f} cm "
                    f"     Median Translation Z Error: {errors_t2[i][:, 2].median():.4f} cm "
                    f"     Std. Translation Z Error: {errors_t2[i][:, 2].std():.4f} cm \n\n")

            # rotation rpy
            f.write("Rotation Error RPY:\n")
            f.write(f"Iteration {i}: \tMean Rotation Roll Error: {errors_rpy[i][:, 0].mean(): .4f} degree"
                    f"     Median Rotation Roll Error: {errors_rpy[i][:, 0].median():.4f} degree"
                    f"     Std. Rotation Roll Error: {errors_rpy[i][:, 0].std():.4f} degree\n")
            f.write(f"Iteration {i}: \tMean Rotation Pitch Error: {errors_rpy[i][:, 1].mean(): .4f} degree"
                    f"     Median Rotation Pitch Error: {errors_rpy[i][:, 1].median():.4f} degree"
                    f"     Std. Rotation Pitch Error: {errors_rpy[i][:, 1].std():.4f} degree\n")
            f.write(f"Iteration {i}: \tMean Rotation Yaw Error: {errors_rpy[i][:, 2].mean(): .4f} degree"
                    f"     Median Rotation Yaw Error: {errors_rpy[i][:, 2].median():.4f} degree"
                    f"     Std. Rotation Yaw Error: {errors_rpy[i][:, 2].std():.4f} degree\n\n\n")

    # for i in range(len(errors_t2)):
    #     errors_t2[i] = torch.stack(errors_t2[i]).abs() / 100
    #     errors_rpy[i] = torch.stack(errors_rpy[i]).abs()

    # mis_calib_input
    # t_x = mis_calib_input[:, 0]
    # t_y = mis_calib_input[:, 1]
    # t_z = mis_calib_input[:, 2]
    # r_roll = mis_calib_input[:, 5]
    # r_pitch = mis_calib_input[:, 3]
    # r_yaw = mis_calib_input[:, 4]

    # plot_error
    # plot_x = errors_t2[:, 0]
    # plot_y = errors_t2[:, 1]
    # plot_z = errors_t2[:, 2]
    # plot_roll = errors_rpy[:, 0]
    # plot_pitch = errors_rpy[:, 1]
    # plot_yaw = errors_rpy[:, 2]

    # translation error
    # fig = plt.figure(figsize=(6, 3))  # 设置图大小 figsize=(6,3)
    # plt.title('Calibration Translation Error')
    '''
        plot_x = np.zeros((mis_calib_input.shape[0], 2))
        plot_x[:, 0] = mis_calib_input[:, 0].cpu().numpy()
        plot_x[:, 1] = errors_t2[-1][:, 0].cpu().numpy()
        plot_x = plot_x[np.lexsort(plot_x[:, ::-1].T)]

        plot_y = np.zeros((mis_calib_input.shape[0], 2))
        plot_y[:, 0] = mis_calib_input[:, 1].cpu().numpy()
        plot_y[:, 1] = errors_t2[-1][:, 1].cpu().numpy()
        plot_y = plot_y[np.lexsort(plot_y[:, ::-1].T)]

        plot_z = np.zeros((mis_calib_input.shape[0], 2))
        plot_z[:, 0] = mis_calib_input[:, 2].cpu().numpy()
        plot_z[:, 1] = errors_t2[-1][:, 2].cpu().numpy()
        plot_z = plot_z[np.lexsort(plot_z[:, ::-1].T)]

        N_interval = plot_x.shape[0] // N
        plot_x = plot_x[::N_interval]
        plot_y = plot_y[::N_interval]
        plot_z = plot_z[::N_interval]

        plt.plot(plot_x[:, 0], plot_x[:, 1], c='red', label='X')
        plt.plot(plot_y[:, 0], plot_y[:, 1], c='blue', label='Y')
        plt.plot(plot_z[:, 0], plot_z[:, 1], c='green', label='Z')
        # plt.legend(loc='best')

        if _config['out_fig_lg'] == 'EN':
            plt.xlabel('Miscalibration (m)', font_EN)
            plt.ylabel('Absolute Error (m)', font_EN)
            plt.legend(loc='best', prop=font_EN)
        elif _config['out_fig_lg'] == 'CN':
            plt.xlabel('初始标定外参偏差/米', font_CN)
            plt.ylabel('绝对误差/米', font_CN)
            plt.legend(loc='best', prop=font_CN)

        plt.xticks(fontproperties='Times New Roman', size=plt_size)
        plt.yticks(fontproperties='Times New Roman', size=plt_size)

        plt.savefig(os.path.join(results_path, 'xyz_plot.png'))
        plt.close('all')

        errors_t = errors_t[-1].numpy()
        errors_t = np.sort(errors_t, axis=0)[:-10]  # 去掉一些异常值
        # plt.title('Calibration Translation Error Distribution')
        plt.hist(errors_t / 100, bins=50)
        # ax = plt.gca()
        # ax.set_xlabel('Absolute Translation Error (m)')
        # ax.set_ylabel('Number of instances')
        # ax.set_xticks([0.00, 0.25, 0.00, 0.25, 0.50])

        if _config['out_fig_lg'] == 'EN':
            plt.xlabel('Absolute Translation Error (m)', font_EN)
            plt.ylabel('Number of instances', font_EN)
        elif _config['out_fig_lg'] == 'CN':
            plt.xlabel('绝对平移误差/米', font_CN)
            plt.ylabel('实验序列数目/个', font_CN)
        plt.xticks(fontproperties='Times New Roman', size=plt_size)
        plt.yticks(fontproperties='Times New Roman', size=plt_size)

        plt.savefig(os.path.join(results_path, 'translation_error_distribution.png'))
        plt.close('all')

        # rotation error
        # fig = plt.figure(figsize=(6, 3))  # 设置图大小 figsize=(6,3)
        # plt.title('Calibration Rotation Error')
        plot_pitch = np.zeros((mis_calib_input.shape[0], 2))
        plot_pitch[:, 0] = mis_calib_input[:, 3].cpu().numpy() * (180.0 / 3.141592)
        plot_pitch[:, 1] = errors_rpy[-1][:, 1].cpu().numpy()
        plot_pitch = plot_pitch[np.lexsort(plot_pitch[:, ::-1].T)]

        plot_yaw = np.zeros((mis_calib_input.shape[0], 2))
        plot_yaw[:, 0] = mis_calib_input[:, 4].cpu().numpy() * (180.0 / 3.141592)
        plot_yaw[:, 1] = errors_rpy[-1][:, 2].cpu().numpy()
        plot_yaw = plot_yaw[np.lexsort(plot_yaw[:, ::-1].T)]

        plot_roll = np.zeros((mis_calib_input.shape[0], 2))
        plot_roll[:, 0] = mis_calib_input[:, 5].cpu().numpy() * (180.0 / 3.141592)
        plot_roll[:, 1] = errors_rpy[-1][:, 0].cpu().numpy()
        plot_roll = plot_roll[np.lexsort(plot_roll[:, ::-1].T)]

        N_interval = plot_roll.shape[0] // N
        plot_pitch = plot_pitch[::N_interval]
        plot_yaw = plot_yaw[::N_interval]
        plot_roll = plot_roll[::N_interval]

        # Yaw（偏航）：欧拉角向量的y轴
        # Pitch（俯仰）：欧拉角向量的x轴
        # Roll（翻滚）： 欧拉角向量的z轴

        if _config['out_fig_lg'] == 'EN':
            plt.plot(plot_yaw[:, 0], plot_yaw[:, 1], c='red', label='Yaw(Y)')
            plt.plot(plot_pitch[:, 0], plot_pitch[:, 1], c='blue', label='Pitch(X)')
            plt.plot(plot_roll[:, 0], plot_roll[:, 1], c='green', label='Roll(Z)')
            plt.xlabel('Miscalibration (degree)', font_EN)
            plt.ylabel('Absolute Error (degree)', font_EN)
            plt.legend(loc='best', prop=font_EN)
        elif _config['out_fig_lg'] == 'CN':
            plt.plot(plot_yaw[:, 0], plot_yaw[:, 1], c='red', label='偏航角')
            plt.plot(plot_pitch[:, 0], plot_pitch[:, 1], c='blue', label='俯仰角')
            plt.plot(plot_roll[:, 0], plot_roll[:, 1], c='green', label='翻滚角')
            plt.xlabel('初始标定外参偏差/度', font_CN)
            plt.ylabel('绝对误差/度', font_CN)
            plt.legend(loc='best', prop=font_CN)

        plt.xticks(fontproperties='Times New Roman', size=plt_size)
        plt.yticks(fontproperties='Times New Roman', size=plt_size)
        plt.savefig(os.path.join(results_path, 'rpy_plot.png'))
        plt.close('all')

        errors_r = errors_r[-1].numpy()
        errors_r = np.sort(errors_r, axis=0)[:-10]  # 去掉一些异常值
        # np.savetxt('rot_error.txt', arr_, fmt='%0.8f')
        # print('max rotation_error: {}'.format(max(errors_r)))
        # plt.title('Calibration Rotation Error Distribution')
        plt.hist(errors_r, bins=50)
        # plt.xlim([0, 1.5])  # x轴边界
        # plt.xticks([0.0, 0.3, 0.6, 0.9, 1.2, 1.5])  # 设置x刻度
        # ax = plt.gca()

        if _config['out_fig_lg'] == 'EN':
            plt.xlabel('Absolute Rotation Error (degree)', font_EN)
            plt.ylabel('Number of instances', font_EN)
        elif _config['out_fig_lg'] == 'CN':
            plt.xlabel('绝对旋转误差/度', font_CN)
            plt.ylabel('实验序列数目/个', font_CN)
        plt.xticks(fontproperties='Times New Roman', size=plt_size)
        plt.yticks(fontproperties='Times New Roman', size=plt_size)
        plt.savefig(os.path.join(results_path, 'rotation_error_distribution.png'))
        plt.close('all')

        if _config["save_name"] is not None:
            torch.save(torch.stack(errors_t).cpu().numpy(), f'./results_for_paper/{_config["save_name"]}_errors_t')
            torch.save(torch.stack(errors_r).cpu().numpy(), f'./results_for_paper/{_config["save_name"]}_errors_r')
            torch.save(torch.stack(errors_t2).cpu().numpy(), f'./results_for_paper/{_config["save_name"]}_errors_t2')
            torch.save(torch.stack(errors_rpy).cpu().numpy(), f'./results_for_paper/{_config["save_name"]}_errors_rpy')

        avg_time = total_time / len(TestImgLoader)
        print("average runing time on {} iteration: {} s".format(len(weights), avg_time))
        print("End!")
    '''